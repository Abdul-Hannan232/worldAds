import React from "react";

const Contact = () => {
  return (
    <div>
      <h1 className='text-center font-bold p-5 text-5xl'>Contact Page</h1>
    </div>
  );
};

export default Contact;
