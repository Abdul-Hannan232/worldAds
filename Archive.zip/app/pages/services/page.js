import React from "react";

const Services = () => {
  return (
    <div>
      <h1 className='text-center font-bold p-5 text-5xl'>services Page</h1>
    </div>
  );
};

export default Services;
