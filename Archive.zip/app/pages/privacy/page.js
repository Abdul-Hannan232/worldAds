import React from "react";

const Privacy = () => {
  return (
    <div>
      <h1 className='text-center font-bold p-5 text-5xl'>Privacy Page</h1>
    </div>
  );
};

export default Privacy;
