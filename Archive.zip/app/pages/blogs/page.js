import React from 'react'

const Blog = () => {
  return (
    <div>
      <h1 className='text-center font-bold p-5 text-5xl'>Blog Page</h1>
    </div>
  )
}

export default Blog
